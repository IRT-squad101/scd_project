<?php
session_start();
?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Historic F1 Results</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }

    body {
      background: #0f0f0f;
      color: #ffffff;
      min-height: 100vh;
      padding: 2rem;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 40px;
      background-color: #000;
      color: #fff;
      position: sticky;
      top: 0;
      z-index: 999;
    }

    .nav-logo {
      font-size: 1.8rem;
      font-weight: bold;
      color: #e10600;
    }

    .nav-links {
      display: flex;
      align-items: center;
    }

    .nav-links a {
      margin: 0 15px;
      color: white;
      text-decoration: none;
      font-size: 1rem;
      position: relative;
    }

    .nav-links a::after {
      content: "";
      display: block;
      width: 0%;
      height: 2px;
      background: #e10600;
      transition: 0.3s ease;
      margin-top: 4px;
    }

    .nav-links a:hover::after {
      width: 100%;
    }

    .nav-toggle {
      display: none;
      font-size: 1.5rem;
      cursor: pointer;
    }

    @media (max-width: 768px) {
      .nav-toggle {
        display: block;
      }

      .nav-links {
        display: none;
        flex-direction: column;
        background-color: #000;
        width: 100%;
        position: absolute;
        top: 70px;
        left: 0;
        padding: 10px 0;
      }

      .nav-links.active {
        display: flex;
      }

      .nav-links a {
        margin: 10px 0;
        text-align: center;
      }

      .race-grid {
        grid-template-columns: 1fr;
      }

      body {
        padding: 1rem;
      }
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 3rem;
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 0.5rem;
      color: #e10600;
    }

    .race-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 2rem;
    }

    .race-card {
      background: #1e1e1e;
      border-radius: 12px;
      padding: 1.5rem;
      transition: transform 0.3s ease;
      border: 1px solid #2e2e2e;
    }

    .race-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    }

    .circuit-name {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: #e10600;
    }

    .session-info {
      margin-bottom: 1rem;
    }

    .date {
      font-size: 0.9rem;
      color: #888;
      margin-bottom: 0.5rem;
    }

    .weather {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #4a90e2;
      font-weight: 500;
    }

    .loading {
      text-align: center;
      font-size: 1.2rem;
      color: #666;
      margin: 2rem 0;
    }

    .error {
      color: #e10600;
      text-align: center;
      padding: 2rem;
    }
  </style>
</head>
<body>

  <nav class="navbar">
    <div class="nav-logo">F1</div>
    <div class="nav-toggle" onclick="toggleMenu()">
      <i class="fas fa-bars"></i>
    </div>
    <div class="nav-links">
         <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
    </div>
  </nav>

  <div class="container">
    <div class="header">
      <h1>Historic F1 Results</h1>
      <p>Explore past Formula One race sessions</p>
    </div>
    <div class="race-grid" id="raceContainer">
      <div class="loading">Loading race data...</div>
    </div>
  </div>

  <script>
    const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

    function toggleMenu() {
      const links = document.querySelector('.nav-links');
      links.classList.toggle('active');
    }

    async function fetchRaceData() {
      try {
        const response = await fetch('https://api.openf1.org/v1/sessions?session_type=Race');
        if (!response.ok) throw new Error('Failed to fetch data');
        const races = await response.json();
        displayRaces(races.slice(0, 10));
      } catch (error) {
        console.error('Error:', error);
        document.getElementById('raceContainer').innerHTML = `
          <div class="error">
            Failed to load race data. Please try again later.
          </div>
        `;
      }
    }

    async function fetchPodium(sessionKey) {
      try {
        const [positionsRes, driversRes] = await Promise.all([
          fetch(`https://api.openf1.org/v1/position?session_key=${sessionKey}`),
          fetch(`https://api.openf1.org/v1/drivers?session_key=${sessionKey}`)
        ]);

        const positions = await positionsRes.json();
        const drivers = await driversRes.json();

        const driverMap = new Map();
        drivers.forEach(driver => {
          driverMap.set(driver.driver_number, driver.full_name);
        });

        const latestPositions = new Map();
        positions.forEach(pos => {
          const current = latestPositions.get(pos.driver_number);
          if (!current || new Date(pos.date) > new Date(current.date)) {
            latestPositions.set(pos.driver_number, pos);
          }
        });

        const top3 = Array.from(latestPositions.values())
          .filter(p => p.position >= 1 && p.position <= 3)
          .sort((a, b) => a.position - b.position);

        if (!top3.length) return 'No podium data';

        return top3.map(p => {
          const name = driverMap.get(p.driver_number) || 'Unknown';
          return `${name} (P${p.position})`;
        }).join('<br>');
      } catch (error) {
        console.error('Podium fetch error:', error);
        return 'Error loading podium';
      }
    }

    async function fetchWeather(sessionKey) {
      try {
        const res = await fetch(`https://api.openf1.org/v1/weather?session_key=${sessionKey}`);
        const data = await res.json();
        if (!data.length) return 'No weather data';
        const sample = data[0];
        return `Temp: ${sample.air_temperature}°C, Humidity: ${sample.humidity}%, Rainfall: ${sample.rainfall}mm`;
      } catch {
        return 'Error loading weather';
      }
    }

    async function displayRaces(races) {
      const container = document.getElementById('raceContainer');
      container.innerHTML = '';

      for (const race of races) {
        const raceDate = new Date(race.date_start).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });

        const [podiumHTML, weatherText] = await Promise.all([
          fetchPodium(race.session_key),
          fetchWeather(race.session_key)
        ]);

        const raceCard = document.createElement('div');
        raceCard.className = 'race-card';
        raceCard.innerHTML = `
          <div class="circuit-name">${race.circuit_short_name}</div>
          <div class="date">${raceDate}</div>
          <div class="session-info">
            <div>Session: ${race.session_name}</div>
            <div>Location: ${race.location}</div>
          </div>
          <div class="session-info">
            <strong>🏆 Podium:</strong><br>
            ${podiumHTML}
          </div>
          <div class="weather">
            <span>☁️</span>
            ${weatherText}
          </div>
        `;

        container.appendChild(raceCard);
      }
    }

    fetchRaceData();

     document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
  </script>
</body>
</html>
