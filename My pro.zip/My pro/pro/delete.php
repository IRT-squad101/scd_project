<?php
include 'db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM f1_quotes WHERE id=$id");
header("Location: read.php");
exit();
?>
