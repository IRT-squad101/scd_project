<?php
session_start();
include 'db.php';

// Check if user is already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    if(empty($username) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        $sql = "SELECT id, username, password FROM f1_users WHERE username = ?";
        if($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $username);
            if($stmt->execute()) {
                $stmt->store_result();
                if($stmt->num_rows == 1) {
                    $stmt->bind_result($id, $username, $hashed_password);
                    if($stmt->fetch()) {
                        if(password_verify($password, $hashed_password)) {
                            session_regenerate_id();
                            $_SESSION['user_id'] = $id;
                            $_SESSION['username'] = $username;
                            header("Location: index.php");
                            exit();
                        } else {
                            $error = "Invalid username or password.";
                        }
                    }
                } else {
                    $error = "Invalid username or password.";
                }
            } else {
                $error = "Oops! Something went wrong. Please try again later.";
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>F1 Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background-color: #000;
            color: #fff;
            z-index: 999;
        }

        .nav-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #e10600;
            letter-spacing: 1px;
        }

         .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            margin: 0 15px;
            color: white;
            text-decoration: none;
            font-size: 1rem;
            position: relative;
        }

        .nav-links a::after {
            content: "";
            display: block;
            width: 0%;
            height: 2px;
            background: #e10600;
            transition: 0.3s ease;
            margin-top: 4px;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .login-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            padding: 40px;
            margin-top: 80px;
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h1 {
            color: #e10600;
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        .form-group input:focus {
            border-color: #e10600;
            outline: none;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color: #e10600;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #c00500;
        }

        .error {
            color: #e10600;
            margin-bottom: 20px;
            text-align: center;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
        }

        .register-link a {
            color: #e10600;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .login-container {
                padding: 30px 20px;
                margin: 80px 20px;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">F1</div>
         <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
    </div>
    </nav>

    <div class="login-container">
        <div class="login-header">
            <h1>Login</h1>
            <p>Access your F1 account</p>
        </div>

        <?php if(!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <div class="register-link">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
    </div>
</body>
<script>
    const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
     document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
</script>
</html>