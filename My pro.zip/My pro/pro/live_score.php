<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>F1 Live Scores</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background-color: #000;
            color: #fff;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .nav-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #e10600;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            margin: 0 15px;
            color: white;
            text-decoration: none;
            font-size: 1rem;
            position: relative;
        }

        .nav-links a::after {
            content: "";
            display: block;
            width: 0%;
            height: 2px;
            background: #e10600;
            transition: 0.3s ease;
            margin-top: 4px;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('https://www.formula1.com/content/dam/fom-website/manual/Misc/2022manual/Race%20Hub%20Header.jpg.transform/9col/image.jpg');
            height: 50vh;
            background-size: cover;
            background-position: center;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .header h1 {
            font-size: 3rem;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .section-title {
            font-size: 2.5rem;
            color: #e10600;
            margin-bottom: 30px;
            text-align: center;
        }

        .live-session {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            overflow: hidden;
        }

        .session-header {
            background: #000;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .session-name {
            font-size: 1.3rem;
            color: #e10600;
            font-weight: bold;
        }

        .session-info {
            font-size: 0.9rem;
            color: #ccc;
        }

        .session-status {
            background: #e10600;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
        }

        .results-table th {
            background: #f5f5f5;
            padding: 12px 15px;
            text-align: left;
            font-weight: bold;
            color: #333;
        }

        .results-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }

        .results-table tr:last-child td {
            border-bottom: none;
        }

        .driver {
            display: flex;
            align-items: center;
        }

        .driver-number {
            background: #e10600;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-weight: bold;
        }

        .driver-name {
            font-weight: bold;
        }

        .team-name {
            color: #666;
            font-size: 0.9rem;
        }

        .loading {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 1.1rem;
        }

        .last-updated {
            text-align: right;
            font-size: 0.9rem;
            color: #666;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 2rem;
            }
            
            .nav-toggle {
                display: block;
            }
            
            .nav-links {
                display: none;
                flex-direction: column;
                background-color: #000;
                width: 100%;
                position: absolute;
                top: 70px;
                left: 0;
                padding: 10px 0;
            }
            
            .nav-links.active {
                display: flex;
            }
            
            .nav-links a {
                margin: 10px 0;
                text-align: center;
            }
            
            .session-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .session-info {
                margin-top: 5px;
            }
            
            .results-table {
                display: block;
                overflow-x: auto;
            }
        }

        footer {
            background: #1f1f1f;
            color: white;
            padding: 30px 0;
            text-align: center;
            margin-top: 60px;
        }

        footer a {
            color: white;
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">F1</div>
        <div class="nav-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>
        <div class="nav-links">
          <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
    </div>
    </nav>

    <header class="header">
        <h1>Live Race Results</h1>
    </header>

    <div class="container">
        <h2 class="section-title">Current Session</h2>
        
        <div id="liveResults">
            <div class="loading">
                <i class="fas fa-spinner fa-spin"></i> Loading live session data...
            </div>
        </div>
        
        <div class="last-updated" id="lastUpdated"></div>
    </div>

    <footer>
        <p>© 2025 Formula 1 World Championship Limited</p>
        <div style="margin-top: 20px;">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
        </div>
    </footer>

    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
       // Toggle mobile menu
        function toggleMenu() {
            const links = document.querySelector('.nav-links');
            links.classList.toggle('active');
        }

        // DOM Elements
        const liveResultsEl = document.getElementById('liveResults');
        const lastUpdatedEl = document.getElementById('lastUpdated');

        // Fetch live race data from OpenF1 API
        async function fetchLiveRaceData() {
            try {
                const response = await fetch('https://api.openf1.org/v1/results?session_key=latest');
                const data = await response.json();
        

                if (data.length === 0) {
                    liveResultsEl.innerHTML = `
                        <div class="live-session">
                            <div class="session-header">
                                <div>
                                    <div class="session-name">No current session available</div>
                                    <div class="session-info">Check back during race weekends for live results</div>
                                </div>
                            </div>
                        </div>
                    `;
                    return;
                }

                renderRaceInfo(data);
                updateLastUpdated();
            } catch (error) {
                console.error('Error fetching live race data:', error);
                liveResultsEl.innerHTML = `
                    <div class="live-session">
                        <div class="session-header">
                            <div>
                                <div class="session-name">Error loading data</div>
                                <div class="session-info">Please try again later</div>
                            </div>
                        </div>
                    </div>
                `;
            }
        }

        // Render race information and results
        function renderRaceInfo(results) {
            // Clear existing content
            liveResultsEl.innerHTML = '';

            // Create session header
            const sessionHeader = document.createElement('div');
            sessionHeader.className = 'session-header';
            sessionHeader.innerHTML = `
                <div>
                    <div class="session-name">Live Race Session</div>
                    <div class="session-info">Real-time race results</div>
                </div>
                <div class="session-status">LIVE</div>
            `;

            // Create results table
            const resultsTable = document.createElement('table');
            resultsTable.className = 'results-table';
            resultsTable.innerHTML = `
                <thead>
                    <tr>
                        <th>Pos</th>
                        <th>Driver</th>
                        <th>Team</th>
                        <th>Laps</th>
                        <th>Time</th>
                        <th>Points</th>
                    </tr>
                </thead>
                <tbody>
                    ${results.map(result => `
                        <tr>
                            <td>${result.position}</td>
                            <td>
                                <div class="driver">
                                    <div class="driver-number">${result.driver_number}</div>
                                    <div>
                                        <div class="driver-name">${result.driver_name}</div>
                                        <div class="team-name">${result.team_name}</div>
                                    </div>
                                </div>
                            </td>
                            <td>${result.team_name}</td>
                            <td>${result.laps}</td>
                            <td>${result.time}</td>
                            <td>${result.points}</td>
                        </tr>
                    `).join('')}
                </tbody>
            `;

            // Append elements to liveResultsEl
            const liveSession = document.createElement('div');
            liveSession.className = 'live-session';
            liveSession.appendChild(sessionHeader);
            liveSession.appendChild(resultsTable);

            liveResultsEl.appendChild(liveSession);
        }

        // Update last updated timestamp
        function updateLastUpdated() {
            const now = new Date();
            lastUpdatedEl.textContent = `Last updated: ${now.toLocaleTimeString()}`;
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            fetchLiveRaceData();
            // Refresh data every 30 seconds
            setInterval(fetchLiveRaceData, 30000);
        });

         document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
    </script>
</body>
</html>