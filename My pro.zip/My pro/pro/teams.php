<?php
session_start();
?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formula 1 Teams</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background-color: #000;
            color: #fff;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .nav-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #e10600;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            margin: 0 15px;
            color: white;
            text-decoration: none;
            font-size: 1rem;
            position: relative;
        }

        .nav-links a::after {
            content: "";
            display: block;
            width: 0%;
            height: 2px;
            background: #e10600;
            transition: 0.3s ease;
            margin-top: 4px;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('f1.avif');
            height: 100vh;
            background-size: cover;
            background-position: center;
            color: white;
            position: relative;
        }

        .header-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        .header-content h1 {
            font-size: 4em;
            margin-bottom: 20px;
            text-transform: uppercase;
        }

        .header-content p {
            font-size: 1.5em;
            margin-top: 10px;
        }

        .team-section {
            padding: 60px 0;
            background: #fff;
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 0 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .team-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .team-card:hover {
            transform: translateY(-5px);
        }

        .team-image {
            height: 200px;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .team-content {
            padding: 20px;
        }

        .team-name {
            color: #e10600;
            margin-bottom: 15px;
            font-size: 1.4rem;
        }

        .team-details p {
            margin: 8px 0;
            font-size: 0.9rem;
            color: #333;
        }

        .team-details strong {
            color: #000;
        }

        @media (max-width: 768px) {
            .team-grid {
                grid-template-columns: 1fr;
            }
            .nav-toggle {
                display: block;
            }
            .nav-links {
                display: none;
                flex-direction: column;
                background-color: #000;
                width: 100%;
                position: absolute;
                top: 70px;
                left: 0;
                padding: 10px 0;
            }
            .nav-links.active {
                display: flex;
            }
            .nav-links a {
                margin: 10px 0;
                text-align: center;
            }
        }

        footer {
            background: #1f1f1f;
            color: white;
            padding: 30px 0;
            text-align: center;
        }

        footer a {
            color: white;
            margin: 0 10px;
        }
           @media (max-width: 768px) {
        .navbar {
            padding: 15px 20px;
        }

        .nav-logo {
            font-size: 1.5rem;
        }

        .header-content h1 {
            font-size: 2.5em;
            line-height: 1.2;
            padding: 0 15px;
        }

        .header-content p {
            font-size: 1.2em;
            padding: 0 15px;
        }

        .team-grid {
            gap: 20px;
            padding: 0 10px;
        }

        .team-image {
            height: 150px;
        }

        .team-name {
            font-size: 1.2rem;
        }

        .team-details p {
            font-size: 0.85rem;
        }

        /* Adjust card hover effect for mobile */
        .team-card:hover {
            transform: none;
        }
    }

    @media (max-width: 480px) {
        .header-content h1 {
            font-size: 2em;
        }

        .header-content p {
            font-size: 1em;
        }

        .team-image {
            height: 120px;
        }

        .team-content {
            padding: 15px;
        }

        footer {
            padding: 20px 0;
        }

        footer p {
            font-size: 0.9rem;
            padding: 0 10px;
        }
    }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">F1</div>
        <div class="nav-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>
        <div class="nav-links">
             <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
        </div>
    </nav>

    <header class="header">
        <div class="header-content">
            <h1>Formula 1 Teams</h1>
            <p>Constructors Championship Contenders</p>
        </div>
    </header>

    <section class="team-section">
        <div class="team-grid">
            <!-- Red Bull Racing -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/red-bull-racing.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Red Bull Racing</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Milton Keynes, UK</p>
                        <p><strong>Team Chief:</strong> Christian Horner</p>
                        <p><strong>Chassis:</strong> RB19</p>
                        <p><strong>Power Unit:</strong> Honda RBPT</p>
                        <p><strong>World Championships:</strong> 5</p>
                    </div>
                </div>
            </div>

            <!-- Mercedes -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/mercedes.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Mercedes-AMG Petronas</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Brackley, UK</p>
                        <p><strong>Team Chief:</strong> Toto Wolff</p>
                        <p><strong>Chassis:</strong> W14</p>
                        <p><strong>Power Unit:</strong> Mercedes</p>
                        <p><strong>World Championships:</strong> 8</p>
                    </div>
                </div>
            </div>

            <!-- Ferrari -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/ferrari.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Scuderia Ferrari</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Maranello, Italy</p>
                        <p><strong>Team Chief:</strong> Frédéric Vasseur</p>
                        <p><strong>Chassis:</strong> SF-23</p>
                        <p><strong>Power Unit:</strong> Ferrari</p>
                        <p><strong>World Championships:</strong> 16</p>
                    </div>
                </div>
            </div>

            <!-- McLaren -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/mclaren.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">McLaren F1 Team</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Woking, UK</p>
                        <p><strong>Team Chief:</strong> Andrea Stella</p>
                        <p><strong>Chassis:</strong> MCL60</p>
                        <p><strong>Power Unit:</strong> Mercedes</p>
                        <p><strong>World Championships:</strong> 8</p>
                    </div>
                </div>
            </div>

            <!-- Alpine -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/alpine.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">BWT Alpine F1 Team</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Enstone, UK</p>
                        <p><strong>Team Chief:</strong> Bruno Famin</p>
                        <p><strong>Chassis:</strong> A523</p>
                        <p><strong>Power Unit:</strong> Renault</p>
                        <p><strong>World Championships:</strong> 2</p>
                    </div>
                </div>
            </div>

            <!-- Aston Martin -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/aston-martin.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Aston Martin Aramco</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Silverstone, UK</p>
                        <p><strong>Team Chief:</strong> Mike Krack</p>
                        <p><strong>Chassis:</strong> AMR23</p>
                        <p><strong>Power Unit:</strong> Mercedes</p>
                        <p><strong>World Championships:</strong> 0</p>
                    </div>
                </div>
            </div>

            <!-- AlphaTauri -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/alphatauri.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Scuderia AlphaTauri</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Faenza, Italy</p>
                        <p><strong>Team Chief:</strong> Franz Tost</p>
                        <p><strong>Chassis:</strong> AT04</p>
                        <p><strong>Power Unit:</strong> Honda RBPT</p>
                        <p><strong>World Championships:</strong> 0</p>
                    </div>
                </div>
            </div>

            <!-- Alfa Romeo -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/alfa-romeo.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Alfa Romeo F1 Team</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Hinwil, Switzerland</p>
                        <p><strong>Team Chief:</strong> Alessandro Alunni Bravi</p>
                        <p><strong>Chassis:</strong> C43</p>
                        <p><strong>Power Unit:</strong> Ferrari</p>
                        <p><strong>World Championships:</strong> 0</p>
                    </div>
                </div>
            </div>

            <!-- Haas -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/haas-f1-team.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">MoneyGram Haas F1 Team</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Kannapolis, USA</p>
                        <p><strong>Team Chief:</strong> Guenther Steiner</p>
                        <p><strong>Chassis:</strong> VF-23</p>
                        <p><strong>Power Unit:</strong> Ferrari</p>
                        <p><strong>World Championships:</strong> 0</p>
                    </div>
                </div>
            </div>

            <!-- Williams -->
            <div class="team-card">
                <div class="team-image" style="background-image: url('https://www.formula1.com/content/dam/fom-website/teams/2023/williams.png.transform/4col/image.png')"></div>
                <div class="team-content">
                    <h3 class="team-name">Williams Racing</h3>
                    <div class="team-details">
                        <p><strong>Base:</strong> Grove, UK</p>
                        <p><strong>Team Chief:</strong> James Vowles</p>
                        <p><strong>Chassis:</strong> FW45</p>
                        <p><strong>Power Unit:</strong> Mercedes</p>
                        <p><strong>World Championships:</strong> 9</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <p>© 2025 Formula 1 World Championship Limited</p>
        <div style="margin-top: 20px;">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
        </div>
    </footer>

    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

        function toggleMenu() {
            const links = document.querySelector('.nav-links');
            links.classList.toggle('active');
        }

         document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
    </script>
</body>
</html>