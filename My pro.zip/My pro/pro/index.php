<?php
session_start();
?>

<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formula 1 - Monaco Grand Prix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
            * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            background-color: #000;
            color: #fff;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .nav-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #e10600;
            letter-spacing: 1px;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            margin: 0 15px;
            color: white;
            text-decoration: none;
            font-size: 1rem;
            position: relative;
        }

        .nav-links a::after {
            content: "";
            display: block;
            width: 0%;
            height: 2px;
            background: #e10600;
            transition: 0.3s ease;
            margin-top: 4px;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        .nav-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('f1.avif');
            height: 100vh;
            background-size: cover;
            background-position: center;
            color: white;
            position: relative;
        }

        .header-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }

        .header-content h1 {
            font-size: 4em;
            margin-bottom: 20px;
            text-transform: uppercase;
        }

        .header-content p {
            font-size: 1.5em;
            margin-top: 10px;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
        }

        .section-title {
            text-align: center;
            margin-bottom: 40px;
            color: #e10600;
            font-size: 2.5em;
        }

        .circuit-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 60px;
        }

        .circuit-image img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .quotes-section {
            background: #f8f9fa;
            padding: 60px 0;
        }

        .quotes-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            padding: 0 20px;
        }

        .quote-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
            transition: transform 0.3s ease;
            border-left: 4px solid #e10600;
        }

        .quote-card:hover {
            transform: translateY(-5px);
        }

        .quote-text {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #333;
            margin-bottom: 15px;
            font-style: italic;
        }

        .quote-author {
            font-weight: bold;
            color: #e10600;
            text-align: right;
        }

        .quote-icon {
            position: absolute;
            top: -20px;
            left: -20px;
            font-size: 2.5rem;
            color: rgba(255, 8, 0, 0.2);
        }

        footer {
            background: #1f1f1f;
            color: white;
            padding: 30px 0;
            text-align: center;
        }

        footer a {
            color: white;
            margin: 0 10px;
        }

        @media (max-width: 768px) {
            .circuit-info {
                grid-template-columns: 1fr;
            }

            .header-content h1 {
                font-size: 2.5em;
            }

            .header-content p {
                font-size: 1em;
            }

            .quotes-container {
                grid-template-columns: 1fr;
            }

            .quote-card {
                padding: 20px;
            }

            .quote-icon {
                top: -15px;
                left: -15px;
                font-size: 2rem;
            }

            .nav-toggle {
                display: block;
            }

            .nav-links {
                display: none;
                flex-direction: column;
                background-color: #000;
                width: 100%;
                position: absolute;
                top: 70px;
                left: 0;
                padding: 10px 0;
            }

            .nav-links.active {
                display: flex;
            }

            .nav-links a {
                margin: 10px 0;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-logo">F1</div>
        <div class="nav-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>
        <div class="nav-links">
                        <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
        </div>
    </nav>

    <header class="header">
        <div class="header-content">
            <h1>Monaco Grand Prix</h1>
            <p>The Crown Jewel of Formula 1</p>
        </div>
    </header>

    <main>
        <section class="container">
            <h2 class="section-title">Circuit de Monaco</h2>
            <div class="circuit-info">
                <div class="circuit-text">
                    <p>The Monaco Grand Prix is widely considered to be one of the most important and prestigious automobile races in the world. The circuit runs through the streets of Monte Carlo and La Condamine around the harbour of the principality of Monaco.</p>
                    <br>
                    <p>First held in 1929, the race is held annually on the Circuit de Monaco, a street circuit laid out on the city streets of Monte Carlo and La Condamine. Known for its narrow streets and tight corners, it is considered one of the most challenging tracks in Formula 1.</p>
                </div>
                <div class="circuit-image">
                    <img src="https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Monaco_Circuit.png.transform/9col/image.png" alt="Monaco Circuit Map">
                </div>
            </div>
         
        </section>

        <section class="quotes-section">
            <div class="container">
                <h2 class="section-title">F1 Driver Quotes</h2>
                <div class="quotes-container">
                    <?php
                        $result = $conn->query("SELECT * FROM f1_quotes ORDER BY RAND() LIMIT 3");
                        while ($row = $result->fetch_assoc()):
                    ?>
                    <div class="quote-card">
                        <i class="fas fa-quote-left quote-icon"></i>
                        <p class="quote-text"><?= htmlspecialchars($row['text']) ?></p>
                        <p class="quote-author">- <?= htmlspecialchars($row['author']) ?></p>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>© 2025 Formula 1 World Championship Limited</p>
        <div style="margin-top: 20px;">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
        </div>
    </footer>

    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
        function toggleMenu() {
            const links = document.querySelector('.nav-links');
            links.classList.toggle('active');
        }

         document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
    </script>
</body>
</html>
