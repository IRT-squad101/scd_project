<?php
session_start();
?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>F1 Drivers - Official</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Arial', sans-serif;
    }

    body {
        background: #ffffff;
        color: #000;
    }

    .header {
        background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)),
                    url('f1.avif');
        background-size: cover;
        background-position: center;
        padding: 100px 20px;
        text-align: center;
        color: white;
    }

    .title {
        font-size: 3.5em;
        text-transform: uppercase;
        letter-spacing: 2px;
    }

    .drivers-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 30px;
        padding: 50px 20px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .driver-card {
        background: #fff;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
        text-align: center;
    }

    .driver-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    .driver-image {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 8px;
    background: rgba(0, 0, 0, 0.05);
    image-rendering: auto;
    image-rendering: crisp-edges;
    image-rendering: -webkit-optimize-contrast;
    transform: scale(1);
}


    .driver-number {
        font-size: 2rem;
        color: #e10600;
        font-weight: bold;
    }

    .driver-name {
        font-size: 1.5rem;
        color: #333;
        margin: 10px 0;
        text-transform: uppercase;
    }

    .driver-team {
        color: #666;
        font-size: 1rem;
        margin-bottom: 10px;
    }

    button {
        background: #e10600;
        color: white;
        border: none;
        padding: 10px 16px;
        cursor: pointer;
        border-radius: 5px;
    }

    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        z-index: 1000;
    }

    .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 10px;
        max-width: 600px;
        margin: 3rem auto;
        position: relative;
        color: #000;
    }

    .modal-driver-image {
        width: 100%;
        max-width: 300px;
        height: auto;
        margin-bottom: 1rem;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.05);
    }

    .close-btn {
        position: absolute;
        top: 1rem;
        right: 1rem;
        color: #e10600;
        font-size: 2rem;
        cursor: pointer;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        margin: 8px 0;
        font-size: 1rem;
    }

    .stats-label {
        color: #e10600;
        font-weight: bold;
    }
    .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    background-color: #000;
    color: #fff;
    position: sticky;
    top: 0;
    z-index: 999;
}

.nav-logo {
    font-size: 1.8rem;
    font-weight: bold;
    color: #e10600;
    letter-spacing: 1px;
}

.nav-links a {
    margin: 0 15px;
    color: white;
    text-decoration: none;
    font-size: 1rem;
    position: relative;
}

.nav-links a::after {
    content: "";
    display: block;
    width: 0%;
    height: 2px;
    background: #e10600;
    transition: 0.3s ease;
    margin-top: 4px;
}

.nav-links a:hover::after {
    width: 100%;
}

.nav-links {
    display: flex;
    align-items: center;
}


    @media (max-width: 768px) {
        .drivers-grid {
            grid-template-columns: 1fr;
            padding: 20px;
        }

        .title {
            font-size: 2em;
        }
    }
</style>

</head>
<body>
    <nav class="navbar">
    <div class="nav-logo">F1</div>
    <div class="nav-links">
           <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
    </div>
</nav>

    <header class="header">
        <h1 class="title">2025 Formula 1 Drivers</h1>
    </header>

    <div class="drivers-grid" id="driversContainer"></div>

    <div class="modal" id="driverModal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <div id="modalContent"></div>
        </div>
    </div>

    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

        const API_BASE = 'https://api.openf1.org/v1/drivers';
        const SESSION_KEY = 9158;

        async function fetchDrivers() {
            try {
                const response = await fetch(`${API_BASE}?session_key=${SESSION_KEY}`);
                const drivers = await response.json();
                displayDrivers(drivers);
            } catch (error) {
                console.error('Error fetching drivers:', error);
            }
        }

        function displayDrivers(drivers) {
            const container = document.getElementById('driversContainer');
            
            drivers.forEach(driver => {
                const card = document.createElement('div');
                card.className = 'driver-card';
                card.innerHTML = `
                    <img src="${driver.headshot_url}" class="driver-image" alt="${driver.full_name}">
                    <div class="driver-number">#${driver.driver_number}</div>
                    <h2 class="driver-name">${driver.full_name}</h2>
                    <p class="driver-team">${driver.team_name}</p>
                    <button onclick="showDriverDetails(${driver.driver_number})" 
                            style="background: var(--f1-red); border: none; padding: 8px 16px; color: white; cursor: pointer;">
                        View Details
                    </button>
                `;
                container.appendChild(card);
            });
        }

        async function showDriverDetails(driverNumber) {
            try {
                const response = await fetch(`${API_BASE}?driver_number=${driverNumber}&session_key=${SESSION_KEY}`);
                const driverData = await response.json();
                const driver = driverData[0];
                
                const modalContent = document.getElementById('modalContent');
                modalContent.innerHTML = `
                    <img src="${driver.headshot_url}" class="modal-driver-image" alt="${driver.full_name}">
                    <h2 style="color: var(--f1-red); font-size: 2.5rem; margin-bottom: 1rem;">${driver.full_name}</h2>
                    <div class="stats-item">
                        <span class="stats-label">Driver Number:</span>
                        <span>#${driver.driver_number}</span>
                    </div>
                    <div class="stats-item">
                        <span class="stats-label">Team:</span>
                        <span>${driver.team_name}</span>
                    </div>
                    <div class="stats-item">
                        <span class="stats-label">Country:</span>
                        <span>${driver.country_code}</span>
                    </div>
                    <div class="stats-item">
                        <span class="stats-label">Session Position:</span>
                        <span>${driver.position || 'N/A'}</span>
                    </div>
                    <div class="stats-item">
                        <span class="stats-label">Broadcast Name:</span>
                        <span>${driver.broadcast_name}</span>
                    </div>
                `;
                
                document.getElementById('driverModal').style.display = 'block';
            } catch (error) {
                console.error('Error fetching driver details:', error);
            }
        }

        function closeModal() {
            document.getElementById('driverModal').style.display = 'none';
        }

        window.onclick = function(event) {
            const modal = document.getElementById('driverModal');
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        }

        fetchDrivers();

         document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
    </script>
</body>
</html>