<!DOCTYPE html>
<html>
<head><title>Add Quote</title></head>
<body>
    <h2>Add New Quote</h2>
    <form action="create.php" method="POST">
        <textarea name="text" placeholder="Quote text" required></textarea><br>
        <input type="text" name="author" placeholder="Author" required><br>
        <button type="submit">Add Quote</button>
    </form>
</body>
</html>
