<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM f1_quotes WHERE id=$id");
$quote = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head><title>Edit Quote</title></head>
<body>
    <h2>Edit Quote</h2>
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $quote['id'] ?>">
        <textarea name="text" required><?= htmlspecialchars($quote['text']) ?></textarea><br>
        <input type="text" name="author" value="<?= htmlspecialchars($quote['author']) ?>" required><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
