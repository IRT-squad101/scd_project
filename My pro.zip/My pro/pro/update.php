<?php
include 'db.php';
$id = $_POST['id'];
$text = $_POST['text'];
$author = $_POST['author'];

$stmt = $conn->prepare("UPDATE f1_quotes SET text=?, author=? WHERE id=?");
$stmt->bind_param("ssi", $text, $author, $id);
$stmt->execute();
$stmt->close();

header("Location: read.php");
exit();
?>
