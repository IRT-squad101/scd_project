<?php
include 'db.php';
$result = $conn->query("SELECT * FROM f1_quotes");
?>
<!DOCTYPE html>
<html>
<head><title>Manage Quotes</title></head>
<body>
    <h2>All Quotes</h2>
    <a href="create_form.php">+ Add New Quote</a>
    <ul>
        <?php while ($row = $result->fetch_assoc()): ?>
            <li>
                "<?= htmlspecialchars($row['text']) ?>" - <?= htmlspecialchars($row['author']) ?>
                [<a href="update_form.php?id=<?= $row['id'] ?>">Edit</a>]
                [<a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this quote?')">Delete</a>]
            </li>
        <?php endwhile; ?>
    </ul>
</body>
</html>
