<?php
session_start();
?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Formula 1</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
            padding: 0;
            margin: 0;
            font-family: 'Arial', sans-serif;
        }

        body {
            line-height: 1.6;
            background-color: #f5f5f5;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #000;
            padding: 20px 40px;
            color: white;
            position: sticky;
            top: 0;
            z-index: 999;
        }

        .nav-logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #e10600;
        }

        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-links a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1rem;
        }

        .nav-links a:hover {
            color: #e10600;
        }

        .nav-toggle {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
        }

        header {
            background: url('https://www.formula1.com/content/dam/fom-website/manual/Misc/2022manual/History%20of%20F1.jpg') no-repeat center center/cover;
            height: 50vh;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        header h1 {
            font-size: 3rem;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
        }

        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .section-title {
            font-size: 2.5rem;
            color: #e10600;
            margin-bottom: 20px;
            text-align: center;
        }

        .about-text {
            font-size: 1.1rem;
            color: #333;
            line-height: 1.8;
            text-align: justify;
        }

        footer {
            background-color: #1f1f1f;
            color: white;
            text-align: center;
            padding: 30px 20px;
            margin-top: 60px;
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none;
                flex-direction: column;
                background-color: #000;
                width: 100%;
                position: absolute;
                top: 70px;
                left: 0;
            }

            .nav-links.active {
                display: flex;
            }

            .nav-links a {
                margin: 10px 0;
                text-align: center;
            }

            .nav-toggle {
                display: block;
            }

            header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">F1</div>
        <div class="nav-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>
        <div class="nav-links">
           <a href="index.php">Home</a>
            <a href="about.php">History</a>
               <a href="drivers.php" data-auth="true">Drivers</a>
            <a href="teams.php" data-auth="true">Teams</a>
            <a href="result.php" data-auth="true">Sessions</a>
            <a href="live_score.php" data-auth="true">Live Score</a>
            <a href="read.php" data-auth="true">Manage Quotes</a>
       <?php if(isset($_SESSION['user_id'])): ?>
        <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
    
        </div>
    </nav>

    <header>
        <h1>The History of Formula 1</h1>
    </header>

    <div class="container">
        <h2 class="section-title">Origins and Evolution</h2>
        <p class="about-text">
            Formula One, often abbreviated as F1, is the pinnacle of motorsport and the most prestigious racing championship in the world. The origins of Formula One can be traced back to the European Grand Prix motor racing of the 1920s and 1930s. The modern Formula One World Championship began in 1950 with the first race held at Silverstone, UK.
        </p>
        <br>
        <p class="about-text">
            Initially dominated by Italian teams like Alfa Romeo, Ferrari, and Maserati, the sport rapidly grew in technological sophistication and global appeal. Over the decades, it has witnessed fierce rivalries, legendary drivers such as Juan Manuel Fangio, Ayrton Senna, Michael Schumacher, and Lewis Hamilton, and groundbreaking engineering developments.
        </p>
        <br>
        <p class="about-text">
            The 1970s and 1980s saw a boom in both safety regulations and corporate sponsorship. Tracks were redesigned for improved driver protection, and cars became faster and more aerodynamically advanced. The 2000s brought further changes, including hybrid engines, advanced telemetry, and global expansion with races across Asia, the Middle East, and the Americas.
        </p>
        <br>
        <p class="about-text">
            Today, Formula One is a multi-billion dollar industry, attracting millions of fans worldwide. It continues to push the boundaries of innovation, combining cutting-edge technology with driver skill, team strategy, and global spectacle.
        </p>
    </div>

    <footer>
        <p>© 2025 Formula 1 World Championship Limited</p>
        <div style="margin-top: 20px;">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
        </div>
    </footer>

    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

        function toggleMenu() {
            const links = document.querySelector('.nav-links');
            links.classList.toggle('active');
        }

 document.querySelectorAll('a[data-auth="true"]').forEach(link => {
    link.addEventListener('click', function (event) {
      if (!isLoggedIn) {
        event.preventDefault(); // Cancel the link action
        alert("You must be logged in to access this page.");
        window.location.href = "login.php"; // Redirect to login
      }
    });
  });
    </script>
</body>
</html>