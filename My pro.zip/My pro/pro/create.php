<?php
include 'db.php';

$text = $_POST['text'];
$author = $_POST['author'];

$stmt = $conn->prepare("INSERT INTO f1_quotes (text, author) VALUES (?, ?)");
$stmt->bind_param("ss", $text, $author);
$stmt->execute();
$stmt->close();

header("Location: read.php");
exit();
?>
